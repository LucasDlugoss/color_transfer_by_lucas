import { app } from "../../scripts/app.js";

// Register the custom node with enhanced UI
app.registerExtension({
    name: "ColorTransferByLucas",
    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "ColorTransferByLucas") {
            // Add custom styling and behavior to the node
            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function () {
                const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
                
                // Set node color scheme
                this.color = "#3a2a5e";
                this.bgcolor = "#2e1e4e";
                
                // Add title styling
                this.title = "🎨 Color Transfer by Lucas";
                
                // Customize widget appearance
                if (this.widgets) {
                    this.widgets.forEach((widget, index) => {
                        // Add custom styling to sliders
                        if (widget.type === "slider" || widget.type === "number") {
                            // Add labels with emojis for better UX
                            switch (widget.name) {
                                case "transfer_strength":
                                    widget.label = "💪 Transfer Strength";
                                    break;
                            }
                        }
                    });
                }
                
                // Add custom properties
                this.properties = this.properties || {};
                this.properties["Node version"] = "1.0.0";
                this.properties["Author"] = "Lucas";
                this.properties["Algorithm"] = "L*a*b* Color Space Transfer";
                
                return r;
            };
            
            // Override the drawing function for custom appearance
            const onDrawForeground = nodeType.prototype.onDrawForeground;
            nodeType.prototype.onDrawForeground = function (ctx) {
                const r = onDrawForeground ? onDrawForeground.apply(this, arguments) : undefined;
                
                // Add a subtle border effect
                ctx.strokeStyle = "#6a5a8a";
                ctx.lineWidth = 2;
                ctx.strokeRect(0, 0, this.size[0], this.size[1]);
                
                // Add author signature in bottom right
                ctx.fillStyle = "#aaa";
                ctx.font = "10px Arial";
                ctx.textAlign = "right";
                ctx.fillText("by Lucas", this.size[0] - 5, this.size[1] - 5);
                
                // Add a small color transfer icon
                ctx.fillStyle = "#ff6b6b";
                ctx.font = "12px Arial";
                ctx.textAlign = "left";
                ctx.fillText("🎨", 5, 20);
                
                return r;
            };
            
            // Add tooltip information
            const getExtraMenuOptions = nodeType.prototype.getExtraMenuOptions;
            nodeType.prototype.getExtraMenuOptions = function (_, options) {
                const r = getExtraMenuOptions ? getExtraMenuOptions.apply(this, arguments) : undefined;
                
                options.push({
                    content: "ℹ️ About Color Transfer",
                    callback: () => {
                        alert(`Color Transfer by Lucas v1.0.0

This node transfers the color palette from a reference image to a content image using L*a*b* color space statistics.

How it works:
1. Converts both images to L*a*b* color space
2. Calculates mean and standard deviation for each channel
3. Applies statistical color transfer
4. Blends result with original based on transfer strength

💪 Transfer Strength: Controls how much of the reference colors are applied
   - 0.0 = No transfer (original image)
   - 1.0 = Full transfer (complete color replacement)

Best practices:
- Use images with similar lighting conditions
- Experiment with different transfer strengths
- Works best with images of similar content types

Created with ❤️ by Lucas`);
                    }
                });
                
                options.push({
                    content: "🔄 Reset Transfer Strength",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                if (widget.name === "transfer_strength") {
                                    widget.value = 1.0;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                options.push({
                    content: "🎯 Preset: Subtle Transfer",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                if (widget.name === "transfer_strength") {
                                    widget.value = 0.3;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                options.push({
                    content: "🌟 Preset: Strong Transfer",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                if (widget.name === "transfer_strength") {
                                    widget.value = 0.8;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                return r;
            };
        }
    }
});

// Add custom CSS styles
const style = document.createElement('style');
style.textContent = `
    .comfy-node[data-title*="Color Transfer by Lucas"] {
        border: 2px solid #6a5a8a !important;
        border-radius: 8px !important;
        box-shadow: 0 4px 12px rgba(106, 90, 138, 0.3) !important;
        background: linear-gradient(135deg, #2e1e4e 0%, #3a2a5e 100%) !important;
    }
    
    .comfy-node[data-title*="Color Transfer by Lucas"] .comfy-widget {
        background: rgba(255, 255, 255, 0.08) !important;
        border-radius: 6px !important;
        margin: 3px 0 !important;
        border: 1px solid rgba(106, 90, 138, 0.3) !important;
    }
    
    .comfy-node[data-title*="Color Transfer by Lucas"] .comfy-widget input[type="range"] {
        background: linear-gradient(90deg, #ff6b6b 0%, #4ecdc4 50%, #45b7d1 100%) !important;
        border-radius: 12px !important;
        height: 8px !important;
    }
    
    .comfy-node[data-title*="Color Transfer by Lucas"] .comfy-widget input[type="range"]::-webkit-slider-thumb {
        background: linear-gradient(45deg, #fff 0%, #f0f0f0 100%) !important;
        border: 2px solid #6a5a8a !important;
        border-radius: 50% !important;
        width: 18px !important;
        height: 18px !important;
        cursor: pointer !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3) !important;
    }
    
    .comfy-node[data-title*="Color Transfer by Lucas"] .comfy-widget input[type="range"]::-moz-range-thumb {
        background: linear-gradient(45deg, #fff 0%, #f0f0f0 100%) !important;
        border: 2px solid #6a5a8a !important;
        border-radius: 50% !important;
        width: 18px !important;
        height: 18px !important;
        cursor: pointer !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3) !important;
    }
    
    .comfy-node[data-title*="Color Transfer by Lucas"] .comfy-widget label {
        color: #e0e0e0 !important;
        font-weight: 500 !important;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5) !important;
    }
`;
document.head.appendChild(style);

