import torch
import numpy as np
from PIL import Image
import cv2

class ColorTransferByLucas:
    """
    A ComfyUI node that transfers the color palette from a reference image to a content image.
    Created by Lucas.
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image_content": ("IMAGE", {"help": "The image to which the color palette will be transferred."}),
                "image_reference": ("IMAGE", {"help": "The image from which the color palette will be taken."}),
                "transfer_strength": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.0,
                        "max": 1.0,
                        "step": 0.01,
                        "display": "slider",
                        "help": "Strength of the color transfer (0.0 = no transfer, 1.0 = full transfer)."
                    },
                ),
            }
        }
    
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("transferred_image",)
    FUNCTION = "apply_color_transfer"
    CATEGORY = "image/color"
    
    def apply_color_transfer(self, image_content, image_reference, transfer_strength):
        """
        Apply color transfer from reference image to content image.
        
        Args:
            image_content: Input content image tensor.
            image_reference: Input reference image tensor.
            transfer_strength: Strength of the color transfer.
        
        Returns:
            Image tensor with transferred colors.
        """
        
        # Ensure both images are 3D (H, W, C) or 4D (B, H, W, C)
        if len(image_content.shape) == 3:
            image_content = image_content.unsqueeze(0) # Add batch dim
        if len(image_reference.shape) == 3:
            image_reference = image_reference.unsqueeze(0) # Add batch dim

        batch_size = image_content.shape[0]
        transferred_images = []

        for i in range(batch_size):
            content_np = image_content[i].cpu().numpy() # Convert to numpy
            reference_np = image_reference[i].cpu().numpy() # Convert to numpy

            # Ensure images are in [0, 255] range and uint8 for OpenCV
            content_np_uint8 = (content_np * 255).astype(np.uint8)
            reference_np_uint8 = (reference_np * 255).astype(np.uint8)

            # Convert to L*a*b* color space
            content_lab = cv2.cvtColor(content_np_uint8, cv2.COLOR_RGB2LAB).astype(np.float32)
            reference_lab = cv2.cvtColor(reference_np_uint8, cv2.COLOR_RGB2LAB).astype(np.float32)

            # Calculate means and standard deviations for each channel
            mean_content, std_content = cv2.meanStdDev(content_lab)
            mean_reference, std_reference = cv2.meanStdDev(reference_lab)

            # Reshape for broadcasting
            mean_content = mean_content.flatten()
            std_content = std_content.flatten()
            mean_reference = mean_reference.flatten()
            std_reference = std_reference.flatten()

            # Apply color transfer in L*a*b* space
            # Subtract content mean, scale by reference std/content std, add reference mean
            transferred_lab = content_lab.copy()
            for j in range(3):
                transferred_lab[:, :, j] = (transferred_lab[:, :, j] - mean_content[j]) * \
                                          (std_reference[j] / (std_content[j] + 1e-6)) + mean_reference[j]
            
            # Blend with original based on transfer_strength
            if transfer_strength < 1.0:
                transferred_lab = content_lab * (1.0 - transfer_strength) + transferred_lab * transfer_strength

            # Convert back to RGB and clip values
            transferred_rgb = cv2.cvtColor(transferred_lab.astype(np.uint8), cv2.COLOR_LAB2RGB)
            transferred_rgb = np.clip(transferred_rgb, 0, 255)

            # Convert back to [0, 1] range for ComfyUI
            transferred_images.append(transferred_rgb.astype(np.float32) / 255.0)

        # Stack back to batch and convert to tensor
        result_tensor = torch.from_numpy(np.stack(transferred_images, axis=0)).float()
        return (result_tensor,)


# Node class mapping for ComfyUI
NODE_CLASS_MAPPINGS = {
    "ColorTransferByLucas": ColorTransferByLucas
}

# Display name mapping
NODE_DISPLAY_NAME_MAPPINGS = {
    "ColorTransferByLucas": "Color Transfer by Lucas"
}

